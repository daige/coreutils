#include <stddef.h>
size_t buffer_lcm (size_t, size_t, size_t) _GL_ATTRIBUTE_CONST;
