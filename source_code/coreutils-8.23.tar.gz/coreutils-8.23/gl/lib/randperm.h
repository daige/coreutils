#include "randint.h"
#include <stddef.h>
size_t randperm_bound (size_t, size_t) _GL_ATTRIBUTE_CONST;
size_t *randperm_new (struct randint_source *, size_t, size_t);
